import modulo
## ATV 1:

print(modulo.interrogatorio())

## ATV 2:

notas = []

print("Soma dos valores:", modulo.soma)
print("Média dos valores:", modulo.media)
print("Quantidade de valores acima da média:", modulo.acima_media)
print("Quantidade de valores abaixo de sete:", modulo.abaixo_sete)
print("Programa encerrado.")

## ATV 3:

modulo.calcula_salarios()

## ATV 4:

modulo.competicao_salto()

## ATV 5:

votos = int(input("Digite os votos: "))
total_votos = int(input("Total de votos: "))
print(modulo.calcula_percentual(votos, total_votos))

## ATV 6:

modulo.enquete()