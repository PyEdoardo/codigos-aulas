def numBool(num):
    if num >= 0:
        return True
    else:
        return False

numero = float(input("Digite o Número: "))

print(numBool(numero))